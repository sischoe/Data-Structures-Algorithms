1.   
    $\Theta(n^2)$ because

    $\begin{align*}
      \sum_{m=0}^{n-1} \sum_{k=0}^{n-1} 1 & = \sum_{m=0}^{n-1} n \\
      &= n^2
    \end{align*}
    $

2.  $\Theta(\sqrt{n})$ because

    $m \cdot m < n$ is equivalent with
    $m < \sqrt{n}$
    
3.  $\Theta(n^4)$ because

    $\begin{align*}
      \sum_{i=0}^{n\cdot n-1} \sum_{j=0}^{i-1} 1 & = \sum_{i=0}^{n^2-1} i \\
      &= \frac{(n^2-1)\cdot n^2}{2}
    \end{align*}
    $
    
4.  $\Theta(\log n)$ because

    $2^m < n$ is equivalent with
    $m < \log_2 n$