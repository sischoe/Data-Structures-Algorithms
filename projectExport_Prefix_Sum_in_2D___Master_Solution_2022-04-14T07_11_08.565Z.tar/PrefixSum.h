#include <vector>
using Matrix = std::vector<std::vector<int>>;


class PrefixSum
{
private:
  Matrix pSum;
  
public:
  
  PrefixSum(const Matrix& a) : pSum(a)
  {
    if(a.size() == 0)
      return;
    
    unsigned Y = a.size();
    unsigned X = a.at(0).size();
    
    for(unsigned x=1; x<X; x++)
      pSum.at(0).at(x) += pSum.at(0).at(x-1);
    for(unsigned y=1; y<Y; y++)
      pSum.at(y).at(0) += pSum.at(y-1).at(0);
    
    
    for(unsigned y=1; y<Y; y++)
      for(unsigned x=1; x<X; x++)
        pSum.at(y).at(x) += (pSum.at(y-1).at(x) + pSum.at(y).at(x-1) - pSum.at(y-1).at(x-1));
  }

  // pre: 0 <= x0 <= x1 < X and 0 <= y0 <= y1 < Y
  // post: return the sum of all pixels in a[y0..y1,x0..x1)
  int sum(unsigned x0, unsigned y0, unsigned x1, unsigned y1)
  {
    int num =                      pSum.at(y1  ).at(x1  );
    int a   = (x0 > 0)           ? pSum.at(y1  ).at(x0-1) : 0;
    int b   = (y0 > 0)           ? pSum.at(y0-1).at(x1  ) : 0;
    int c   = (y0 > 0 && x0 > 0) ? pSum.at(y0-1).at(x0-1) : 0;
    return (num - a - b + c);
  }
};

/* alternative solution: 

class PrefixSum
{
private:
  Matrix pSum; // matrix size one larger than a in x and y
  
public:
  
  PrefixSum(const Matrix& a)
  {
    unsigned Y = a.size();
    unsigned X = a.at(0).size();

    pSum = std::vector<std::vector<int>>(Y+1,std::vector<int>(X+1,0));

    // first row and first column
    for(unsigned y=0; y != Y; y++)
      for(unsigned x=0; x != X; x++)
        pSum.at(y+1).at(x+1) = a.at(y).at(x) + (pSum.at(y).at(x+1) + pSum.at(y+1).at(x) - pSum.at(y).at(x));
  }

  // pre: 0 <= x0 <= x1 < X and 0 <= y0 <= y1 < Y
  // post: return the sum of all pixels in a[y0..y1,x0..x1)
  int sum(unsigned x0, unsigned y0, unsigned x1, unsigned y1)
  {
    return pSum.at(y1+1).at(x1+1)-pSum.at(y1+1).at(x0)-pSum.at(y0).at(x1+1)+pSum.at(y0).at(x0);
  }
};

*/