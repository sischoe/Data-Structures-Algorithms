import os
from matplotlib import pyplot as plt

def draw(name,x,y1,y2):
  """Draw the tour if the code was run manually."""
  fig = plt.figure(figsize=(12,8))
  axes = fig.add_subplot()
  axes.set_title(name)
  axes.plot(x,y1,label="mine")
  axes.plot(x,y2,label="yours")
  axes.legend()
  fig.savefig("cx_out/measure"+name+".png", bbox_inches="tight")
  
def main():
  # only draw a graph when not testing or submitting
  if os.environ["ACTION"] != "run":
    return
  with open("measure.txt","r") as f:
    lines = f.readlines()
    new_file = False
    for (name, x, y1, y2) in zip(lines[0::4], lines[1::4], lines[2::4], lines[3::4]):
      name = name.rstrip()
      x = [int(v) for v in x.split(",")]
      y1 = [float(v) for v in y1.split(",")]
      y2 = [float(v) for v in y2.split(",")]
      if len(x) > 1:
        draw(name,x,y1,y2)
        new_file = True
    if new_file:
      print("graphical comparisons available. Open 'Files' tab")

if __name__ == '__main__':
  main()