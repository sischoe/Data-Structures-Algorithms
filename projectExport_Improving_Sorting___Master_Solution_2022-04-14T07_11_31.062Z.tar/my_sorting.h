std::vector<Value> my_sort(std::vector<Value> a){
  std::size_t n = a.size();
  for (std::size_t i = 0; i<n ; ++i)
    for (std::size_t j = i+1; j<n; ++j)
      if (a[j] < a[i])
        swap(a[i],a[j]);
  return a;
}

