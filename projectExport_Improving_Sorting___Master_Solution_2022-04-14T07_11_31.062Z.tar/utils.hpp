#include <ctime>
#include <sstream>
#include <iomanip>
#include <sys/time.h>

// ************** NOTE ************** NOTE ************** NOTE **************
//
// This code goes beyond what is relevant for the course, i.e. you don't
// need to understand this code for the exam. 
// If you are interested and curious, however, have a look and experiment.
//
// ************** NOTE ************** NOTE ************** NOTE **************

// Very simple time taker to measure elapsed time
struct Timer {
  // not as portable and nice as std::chrono, but at least we can measure CPU time
  struct timespec start_cpu, end_cpu;

  void tick() {
    clock_gettime(CLOCK_THREAD_CPUTIME_ID, &start_cpu);
  }
  
  void tock() {
    clock_gettime(CLOCK_THREAD_CPUTIME_ID, &end_cpu);
  }
  
  double elapsed() {
    double time_taken;
    time_taken = (end_cpu.tv_sec - start_cpu.tv_sec) * 1e9;
    time_taken = (time_taken + (end_cpu.tv_nsec - start_cpu.tv_nsec)) * 1e-9;
    return time_taken;
  }
};