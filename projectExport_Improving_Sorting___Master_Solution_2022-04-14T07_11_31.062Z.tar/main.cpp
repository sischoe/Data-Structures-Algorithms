#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include "data.h"
#include "utils.hpp"
#include <cassert>
#include "my_sorting.h"
#include "your_sorting.h"

template <typename element>
std::ostream& operator<<(std::ostream& out, const std::vector<element>& v){
  bool first = true;
  for (const auto& x: v){
    if (first){
      first = false;
    } else {
      out << ", ";
    }
    out << x;
  }
  return out;
}

void drive_test(unsigned n, unsigned m, unsigned repetitions, std::string type, std::ostream& of){
  const unsigned output_threshold = 30;
  Data data;
  Timer timer;
  of << type << std::endl;
  std::vector<unsigned> sz;
  std::vector<double> to;
  std::vector<double> tm;
  for (unsigned i = 1; i<=m; ++i){
    unsigned k = n * i / m;
    sz.push_back(k);
    auto orig = data.get_vector(k,data.getDataType(type));
    if (k == n){
      std::cout << "-------------------------------------------------------------" << std::endl;
      std::cout << "n = " << n << " " << type << " ";
      if (n <= output_threshold){
        std::cout << orig;
      }
      std::cout << std::endl;
      if (repetitions>1){
        std::cout << "repetitions: " << repetitions << std::endl;
      }
    }
    auto my_sorted = orig;
    auto your_sorted1 = orig;
    auto your_sorted2 = orig;
    auto your_sorted3 = orig;
    
    auto swaps1 = value_swaps;
    auto comparisons1 = value_comparisons;
    timer.tick();
    for (unsigned r = 0; r<repetitions; ++r)
      my_sorted = my_sort(orig);
    timer.tock();
    swaps1 = value_swaps - swaps1;
    comparisons1 = value_comparisons - comparisons1;
    auto t1 = timer.elapsed();

    auto swaps2 = value_swaps;
    auto comparisons2 = value_comparisons;
    timer.tick();
    for (unsigned r = 0; r<repetitions; ++r)
      your_sorted1 = your_sort1(orig);
    timer.tock();
    swaps2 = value_swaps - swaps2;
    comparisons2 = value_comparisons-comparisons2;
    auto t2 = timer.elapsed();
    
    auto swaps3 = value_swaps;
    auto comparisons3 = value_comparisons;
    timer.tick();
    for (unsigned r = 0; r<repetitions; ++r)
      your_sorted2 = your_sort2(orig);
    timer.tock();
    swaps3 = value_swaps - swaps3;
    comparisons3 = value_comparisons-comparisons3;
    auto t3 = timer.elapsed();
    
    auto swaps4 = value_swaps;
    auto comparisons4 = value_comparisons;
    timer.tick();
    for (unsigned r = 0; r<repetitions; ++r)
      your_sorted3 = your_sort3(orig);
    timer.tock();
    swaps4 = value_swaps - swaps4;
    comparisons4 = value_comparisons-comparisons4;
    auto t4 = timer.elapsed();

    to.push_back(t1);
    tm.push_back(t2);
    if (k == n){
      if (n <=  output_threshold ){
        std::cout << "sorted 1 " << your_sorted1 << std::endl;
        std::cout << "sorted 2 " << your_sorted2 << std::endl;
        std::cout << "sorted 3 " << your_sorted3 << std::endl;
      }
      std::cout << "        \t     time \t     swaps \t comparisons \t speedup" << std::endl;
      std::cout << "mine    \t" << std::setprecision(5) << t1;
      std::cout << "\t" << std::setw(10) << swaps1; 
      std::cout << "\t" << std::setw(10) << comparisons1;
      std::cout << "\t" << std::setw(7) << "" << std::endl;
      std::cout << "yours 1 \t" << std::setprecision(5) << t2;
      std::cout << "\t" << std::setw(10) << swaps2 ;
      std::cout << "\t" << std::setw(10) << comparisons2;
      std::cout << "\t" << std::setw(7) << std::setprecision(2) << double(t1)/t2 << std::endl;
      std::cout << "yours 2 \t" << std::setprecision(5) << t3;
      std::cout << "\t" << std::setw(10) << swaps3 ;
      std::cout << "\t" << std::setw(10) << comparisons3;
      std::cout << "\t" << std::setw(7) << double(t1)/t3 << std::endl;
      std::cout << "yours 3 \t" << std::setprecision(5) << t4;
      std::cout << "\t" << std::setw(10) << swaps4 ;
      std::cout << "\t" << std::setw(10) << comparisons4;
      std::cout << "\t" << std::setw(7) << double(t1)/t4 << std::endl;
    }
    assert(your_sorted1 == my_sorted);
  }
  of << sz << std::endl;
  of << to << std::endl;
  of << tm << std::endl;
}

int main(){
  unsigned n, m, r;
  std::cout << "Enter n [m [r]] " << std::endl;
  std::string line;
  std::getline(std::cin,line);
  std::stringstream input(line);
  n = 10000; m = 1; r = 1;
  input >> n >> m >> r;
  if (m<1)
    m = 1;
  if (r<1)
    r = 1;
  std::ofstream ofn("measure.txt");
  drive_test(n, m, r, "descending", ofn);
  drive_test(n, m, r, "random", ofn);
  drive_test(n, m, r, "almost_sorted", ofn);
  drive_test(n, m, r, "ascending", ofn);
  return 0;
}
