#include <random>

enum class DataType {
  ascending,
  descending,
  almost_sorted,
  random,
  unknown
};

unsigned value_swaps = 0;
unsigned value_comparisons = 0;
unsigned value_allocs = 0;

class Value{
  int val;
public:
  Value(int v):val(v){}
  Value(): Value(0){}
  
  std::ostream& output(std::ostream& out) const{
    return out << val;
  }
  
  bool operator <(const Value& other) const{
    value_comparisons++;
    return val < other.val;
  }
  bool operator <=(const Value& other) const{
    value_comparisons++;
    return val <= other.val;
  }
  bool operator >(const Value& other) const{
    value_comparisons++;
    return val > other.val;
  }
  bool operator >=(const Value& other) const{
    value_comparisons++;
    return val >= other.val;
  }
  bool operator ==(const Value& other) const{
    value_comparisons++;
    return val == other.val;
  }
  bool operator !=(const Value& other) const{
    value_comparisons++;
    return val == other.val;
  }
  void swap(Value& other){
    value_swaps++;
    std::swap(other.val,val);
  }
};

std::ostream& operator<<(std::ostream& out, const Value& v){
  return v.output(out);
}

void swap(Value& v1, Value& v2){
  v1.swap(v2);
}

// class to generate pseudo random numbers
class Data{

public:
  DataType getDataType(std::string name){
    if (name == "ascending")
      return DataType::ascending;
    else if (name == "descending")
      return DataType::descending;
    else if (name == "almost_sorted")
      return DataType::almost_sorted;
    else if (name == "random")
      return DataType::random;
    else {
      std::cerr << "unknown data type";
      return DataType::unknown;
    }
  }
  
  std::string getName(DataType type){
    switch (type){
      case DataType::ascending: return "ascending";
      case DataType::descending: return "descending";
      case DataType::almost_sorted: return "almost_sorted";
      case DataType::random: return "random";
      case DataType::unknown: return "unknown";
    }
    return "unknown";
  }

  std::vector<Value> get_vector(unsigned n, DataType type = DataType::random){
    std::vector<Value> result;
    switch (type)
    {
      case DataType::ascending:
        for (unsigned i = 0; i<n; ++i){
          result.push_back(i);
        }
        return result;
      case DataType::descending:{
        for (unsigned i = 0; i<n; ++i){
          result.push_back(n-i-1);
        }
        return result;
      }
      case DataType::almost_sorted:{
        for (unsigned i = 0; i<n; ++i){
          result.push_back(i);
        }
        std::mt19937 gen;
        std::uniform_int_distribution<> dis(0,n);
        for (unsigned i = 0; i<n/10;++i){
          swap(result[dis(gen)],result[dis(gen)]);
        }
        return result;
      }
      default:{
        std::mt19937 gen;
        std::uniform_int_distribution<> dis(-n,n);
        for (unsigned i = 0; i<n; ++i){
          result.push_back(dis(gen));
        }
        return result;
      }
    }
  }
};
