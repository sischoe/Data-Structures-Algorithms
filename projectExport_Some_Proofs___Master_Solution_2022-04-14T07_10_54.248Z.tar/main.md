# Master solution

1. $f\in \bigO(g)$ if and only if $g\in\Omega(f)$.  
   The statement is true. It follows directly from the definitions of $\bigO(g)$ and $\Omega(f)$, as it is
   $$
   \begin{align*}
   f\in \bigO(g) & \Leftrightarrow \exists c_1 \in \R^+, n_0 \in \N: \forall n \geq n_0: f(n) \leq c_1 \cdot g(n)
   \\& \Leftrightarrow \exists c_2 \in \R^+, n_0 \in \N: \forall n \geq n_0: g(n) \geq c_2 \cdot f(n) \\&\Leftrightarrow g\in \Omega(f).
   \end{align*}
   $$
   We can choose $c_2=c_1^{-1}$.
1. If $f\in \bigO(g)$ then $f(n) \leq g(n)$ for every $n\in \N$.  
   This is a false statement. Choose, for example, $f(n) = 2n$ and $g(n)=n^2$. Then, $f\in \bigO(g)$, but $f(1)>g(1)$.
1. If $f(n) \leq g(n)$ for every $n\in\N$, then $f\in\bigO(g)$.  
   This statement is true, as $f(n) \leq c \cdot g(n)$ is satisfied for $c=1$.
1. There exist different functions $f\in \Omega(g)$ and $g\in \Omega(f)$.  
   This statement is true, for example for $f(n) = n$ and $g(n) = 2n$.
1. $\log_a(n) \in \Theta(\log_b(n))$ for all constants $a, b\in\N \setminus\{1\}$  
   This statement is true. For all $a,b \in \N$ it holds that $\log_a(n) = \frac{log_b(n)}{\log_b(a)}$. We set $n_0=1$ and $c=1/\log_b(a)$. Then it holds for all $n \geq n_0$ that
   $$
   \log_a(n) \leq c \log_b(n) \text{ and } \log_a(n) \geq c \log_b(n) .
   $$
   Therefore, $\log_a(n) \in \bigO(\log_b(n))$ and $\log_a(n) \in \Omega(\log_b(n))$ and thus $\log_a(n) \in \Theta(\log_b(n))$.
1. If $f_1, f_2 \in \bigO(g)$ and $f(n) := f_1(n) + f_2(n)$, then $f\in \bigO(g)$.  
   The statement is true. By definition
   $$
   f_1\in \bigO \Leftrightarrow \exists c_1 \in \R^+, n_1 \forall n \geq n_1: f_1(n) \leq c_1 \cdot g(n)
   $$
   $$
   f_2\in \bigO \Leftrightarrow \exists c_2 \in \R^+, n_2 \forall n \geq n_2: f_2(n) \leq c_2 \cdot g(n) \\
   $$
   With $c:=c_1 + c_2$ and $n_0:=\max{n_1,n_2}$ it holds for all $n\geq n_0$ that
   $$
   f(n) = f_1(n)+f_2(n) \leq c_1 \cdot g(n) + c_2 \cdot g(n) = c \cdot g(n).
   $$
   Therefore, $f\in \bigO(g)$.
1. If $f_1, f_2 \in \bigO(g)$ and $f(n) := f_1(n) \cdot f_2(n)$, then $f\in \bigO(g)$.  
   This statement is false. One can choose $f_1(n)=f_2(n) = n$ and $g(n) = n$. Then $f_1, f_2 \in \bigO(g)$, but $f(n) = f_1(n) \cdot f_2(n) = n^2 \in \bigO(n)$ (there exists no constant $c>0$ and $n_0$, such that $n^2 \leq c \cdot n$ applies for all $n\geq n_0$).
1. $n^{1/a} \in \Theta(n^{1/b})$ for all $a,b\in \N$, $a\leq b$.  
   This statement is true, if $a=b$. But if $a<b$, the statement is not true.
   $$
   \lim_{n\to \infty} \frac{n^{1/a}}{n^{1/b}} =
   \lim_{n\to\infty} n^{\frac{b-a}{ab}} = \infty
   $$
   Therefore $n^{1/b} \in \bigO(n^{1/a}), \bigO(n^{1/b}) \varsubsetneq \bigO(n^{1/a})$.
